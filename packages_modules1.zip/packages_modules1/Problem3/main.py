from number_utils import is_prime, is_palindrome, is_armstrong, is_perfect

number = int(input("Enter a number: "))

if is_prime(number):
    print("Prime number")
else:
    print("Not a prime number")

if is_palindrome(number):
    print("Palindrome number")
else:
    print("Not a palindrome number")

if is_armstrong(number):
    print("Armstrong number")
else:
    print("Not an Armstrong number")

if is_perfect(number):
    print("Perfect number")
else:
    print("Not a perfect number")