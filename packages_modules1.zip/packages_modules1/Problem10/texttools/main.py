from texttools.cleaning import remove_punctuation, remove_extra_spaces
from texttools.tokenization import tokenize
from texttools.frequency import word_frequency

text = input("Enter a text: ")

cleaned_text = remove_punctuation(text)
cleaned_text = remove_extra_spaces(cleaned_text)

print("\n--- Text Cleaning ---")
print("Cleaned Text:", cleaned_text)

print("\n--- Tokenization ---")
print("Words:", tokenize(cleaned_text))

print("\n--- Word Frequency ---")
print(word_frequency(cleaned_text))