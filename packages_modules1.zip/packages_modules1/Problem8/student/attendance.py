def attendance_percentage(present, total):
    return (present / total) * 100


def is_eligible(attendance):
    return attendance >= 75