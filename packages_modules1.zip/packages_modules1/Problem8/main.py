from student.marks import total_marks, percentage
from student.grade import calculate_grade
from student.attendance import attendance_percentage, is_eligible

name = input("Enter student name: ")

marks = []

for i in range(5):
    mark = float(input("Enter marks of subject " + str(i + 1) + ": "))
    marks.append(mark)

present = int(input("Enter lectures attended: "))
total_lectures = int(input("Enter total lectures: "))

total = total_marks(marks)
percent = percentage(marks)
grade = calculate_grade(percent)

attendance = attendance_percentage(present, total_lectures)

print("\n--- Student Report ---")
print("Name:", name)
print("Total Marks:", total)
print("Percentage:", percent)
print("Grade:", grade)
print("Attendance:", attendance)

if is_eligible(attendance):
    print("Attendance Eligibility: Eligible")
else:
    print("Attendance Eligibility: Not Eligible")