def create_account(name, account_number, balance):
    return {
        "name": name,
        "account_number": account_number,
        "balance": balance
    }


def get_balance(account):
    return account["balance"]