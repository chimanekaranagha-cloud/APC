from banking.account import create_account, get_balance
from banking.transaction import deposit, withdraw
from banking.loan import calculate_loan

name = input("Enter account holder name: ")
account_number = input("Enter account number: ")
balance = float(input("Enter initial balance: "))

account = create_account(name, account_number, balance)

print("\n--- Account Details ---")
print("Name:", account["name"])
print("Account Number:", account["account_number"])
print("Balance:", get_balance(account))

deposit_amount = float(input("\nEnter deposit amount: "))
deposit(account, deposit_amount)
print("Balance after deposit:", get_balance(account))

withdraw_amount = float(input("Enter withdrawal amount: "))
result = withdraw(account, withdraw_amount)
print("Withdrawal result:", result)
print("Current balance:", get_balance(account))

principal = float(input("\nEnter loan amount: "))
rate = float(input("Enter interest rate: "))
time = float(input("Enter time in years: "))

interest, total = calculate_loan(principal, rate, time)

print("\n--- Loan Details ---")
print("Interest:", interest)
print("Total Loan Amount:", total)