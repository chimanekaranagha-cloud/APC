def product_details():
    print("Product Name: Laptop")
    print("Product Price: 50000")