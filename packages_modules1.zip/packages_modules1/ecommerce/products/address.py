def customer_address():
    print("City: Kolhapur")
    print("State: Maharashtra")