def show_catalog():
    print("1. Laptop")
    print("2. Mobile")
    print("3. Headphones")