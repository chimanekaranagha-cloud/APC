def create_order():
    print("Order ID: O101")
    print("Order created successfully.")