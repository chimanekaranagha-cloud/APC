def payment_method():
    print("Payment Method: UPI")