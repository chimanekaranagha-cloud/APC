def order_status():
    print("Order Status: Shipped")