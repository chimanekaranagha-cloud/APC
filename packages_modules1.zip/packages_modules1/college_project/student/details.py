def student_details():
    print("Student Name: Anagha")
    print("Roll Number: 101")
    print("Branch: Computer Engineering")