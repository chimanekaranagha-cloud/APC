def student_marks():
    print("Python: 85")
    print("Java: 80")
    print("Database: 90")