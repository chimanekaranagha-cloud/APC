def faculty_details():
    print("Faculty Name: Professor Patil")
    print("Department: Computer Engineering")
    print("Designation: Professor")