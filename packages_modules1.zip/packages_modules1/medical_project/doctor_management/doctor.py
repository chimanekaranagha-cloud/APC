def doctor_details():
    print("Doctor Name: Dr. Patil")
    print("Doctor ID: D101")
    print("Specialization: General Physician")