def patient_details():
    print("Patient Name: Anagha")
    print("Patient ID: P101")
    print("Age: 20")
    