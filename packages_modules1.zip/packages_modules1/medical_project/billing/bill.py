def calculate_bill(consultation_fee, medicine_fee):
    total = consultation_fee + medicine_fee
    return total


def display_bill(consultation_fee, medicine_fee):
    total = calculate_bill(consultation_fee, medicine_fee)

    print("Consultation Fee:", consultation_fee)
    print("Medicine Fee:", medicine_fee)
    print("Total Bill:", total)