def medical_record():
    print("Disease: Fever")
    print("Treatment: Medicines prescribed")
    print("Status: Under Treatment")