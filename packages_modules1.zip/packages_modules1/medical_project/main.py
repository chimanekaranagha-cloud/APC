from patient_management.patient import patient_details
from doctor_management.doctor import doctor_details
from billing.bill import display_bill
from medical_records.record import medical_record

print("===== MEDICAL MANAGEMENT SYSTEM =====")

print("\n--- Patient Details ---")
patient_details()

print("\n--- Doctor Details ---")
doctor_details()

print("\n--- Medical Record ---")
medical_record()

print("\n--- Billing Details ---")
display_bill(500, 1000)