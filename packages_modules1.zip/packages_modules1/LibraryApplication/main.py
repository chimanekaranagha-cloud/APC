from books.book import Book
from books.book_search import search_book

from members.member import Member
from members.member_search import search_member

from transactions.issue import issue_book
from transactions.return_book import return_book


# Create books
book1 = Book(101, "Python Programming", "John Smith")
book2 = Book(102, "Java Programming", "James Brown")

books = [book1, book2]


# Create members
member1 = Member(1, "Anagha")
member2 = Member(2, "Rahul")

members = [member1, member2]


# Display book
print("----- BOOK DETAILS -----")
book1.display_book()


# Search book
print("\n----- SEARCH BOOK -----")
search_book(books, "Python Programming")


# Display member
print("\n----- MEMBER DETAILS -----")
member1.display_member()


# Search member
print("\n----- SEARCH MEMBER -----")
search_member(members, 1)


# Issue book
print("\n----- TRANSACTION -----")
issue_book(book1, member1)


# Return book
return_book(book1, member1)