def issue_book(book, member):
    print("\nBook Issued Successfully!")
    print("Book:", book.title)
    print("Issued To:", member.name)