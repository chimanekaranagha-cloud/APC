def search_book(books, title):
    for book in books:
        if book.title.lower() == title.lower():
            print("Book Found:")
            book.display_book()
            return book

    print("Book Not Found")
    return None