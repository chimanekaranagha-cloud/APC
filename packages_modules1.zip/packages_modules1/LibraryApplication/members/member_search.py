def search_member(members, member_id):
    for member in members:
        if member.member_id == member_id:
            print("Member Found:")
            member.display_member()
            return member

    print("Member Not Found")
    return None