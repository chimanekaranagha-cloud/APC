file = open("student1.txt", "w")

file.write("Name: Anagha\n")
file.write("Roll No: 114\n")
file.write("Branch: Computer Engineering\n")
file.write("Semester: 5\n")

file.close()

print("Student information written successfully.")