file = open("student1.txt", "r")

data = file.read()

print(data)

file.close()